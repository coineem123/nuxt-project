<template>
    <v-app>
        <HeaderPart> </HeaderPart>
        <div id="main">
            <table id="mainTable">
                <tr>
                    <label>LOGIN</label>
                </tr>
                <tr>
                    <TextField :id="'accountTextField'" :isPassword="false" :maxLength="20" :size="20" :label="'Account'" :icon="'mdi-account-box-outline'"></TextField>
                </tr>
                <tr>
                    <TextField :id="'passwordTextField'" :isPassword="true" :maxLength="20" :size="20" :label="'Password'" :icon="'mdi-lock'"></TextField>
                </tr>
            </table>
        </div>
        <FooterPart> </FooterPart>

    </v-app>
</template>
