<script setup>

</script>

<template>
    <header>
        <div id="header-text">
            <p>
            CREATE WITH
            </p>
        </div>
        <div id="header-image">
            <v-img width="100px" src="/vue-logo.svg" height="100px"></v-img>
            <v-img width="100px" src="/nuxt-logo.png" height="100px"></v-img>
            <v-img width="100px" src="/vuetify-logo.png" height="100px"></v-img>

        </div>

    </header>
</template>

<style>
    @import url("/assets/css/HeaderPart.css");

</style>