<script setup>
    import { ref } from 'vue'
    const props = defineProps({
        id: String,
        isPassword: Boolean,
        maxLength: Number,
        size: Number,
        label: String,
        icon: String
    })
    const showPassword = ref(false)
    const inputRef = ref(null)
    function changeShowPassword() {
        showPassword.value = !showPassword.value
        if (showPassword.value) {
            inputRef.value.type = 'text'
        } else {
            inputRef.value.type = 'password'
        }
    }
</script>

<template>
    <div>
        <table>
            <tr>
                <td width="100px">
                    <v-icon>{{icon}} </v-icon>
                    <label for="{{id}}">{{label}}</label>
                </td>
                <td>
                    <input :id="id" :type="isPassword ? 'password':'text'" :maxlength="maxLength" :size="size" ref="inputRef" />
                </td>
                <td width="100px">
                    <v-hover v-slot="{ hover }">
                        <v-icon v-if="isPassword" :color="hover ? 'red':''" @click="changeShowPassword">
                            {{showPassword ? 'mdi-eye':'mdi-eye-closed'}}
                        </v-icon>
                    </v-hover>
                </td>
            </tr>
        </table>
    </div>
</template>

<style>
    @import url("/assets/css/TextField.css");
</style>