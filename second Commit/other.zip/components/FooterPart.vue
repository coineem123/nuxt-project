<script setup>

</script>

<template>
    <footer>
        <div id="footer-text">
            <p>
            CREATE BY VO NGUYEN CHAU THUAN
            </p>
        </div>
    </footer>
</template>

<style>
    @import url("/assets/css/FooterPart.css");

</style>